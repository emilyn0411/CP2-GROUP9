# MotorPH Employee Management and Payroll System   (MS2 SUBMISSION)

This is a Java Swing-based GUI application for managing employees, tracking time, and computing payroll for the MotorPH company. Built using NetBeans and Maven, it includes login authentication, employee CRUD operations, payroll calculation, and time tracking with a 12/24-hour digital clock.

---

##  Features

### 1. **User Authentication**
- Login screen with credentials stored in `credentials.txt`
- Session management using `SessionManager.java`

### 2. **Dashboard**
- Main landing window after login
- Three main tabs:
  - **Employees** – Add, edit, delete, and view employee details
  - **Time Tracker** – Real-time digital clock with 12/24-hour toggle and clock in/out functionality
  - **Payroll** – Auto-calculated salary breakdowns with gross, deductions, and net pay

### 3. **Employee Management**
- Employee records include:
  - Full name, birthday, contact, government IDs (SSS, PhilHealth, TIN, Pag-ibig)
  - Employment status, position, supervisor
  - Salary components: basic, rice, phone, clothing, gross, hourly rate
- Stored in `employee_data.txt` in `src/main/resources/`

### 4. **Payroll Processing**
- **Gross Pay** = Basic Salary + Rice Subsidy + Phone Allowance + Clothing Allowance  
- **Deductions**:
  - SSS (4.5%), PhilHealth (3%), Pag-ibig (2%), Tax (5%)
- **Net Pay** = Gross Pay − Deductions
- Data pulled from `employee_data.txt`  
- Additional raw data (if used) stored in `payroll_data.txt`

### 5. **Time Tracking**
- Real-time digital clock with toggle between 12-hour and 24-hour format
- Buttons to log Clock In and Clock Out events
- Time logs stored in `timelogs.txt`

---

## 📁 Project Structure

MotorPH-Employee-App/
├── README.md
├── pom.xml
├── src/
│ └── main/
│ ├── java/
│ │ └── com.motorph.motorph.employee.app/
│ │ ├── auth/
│ │ ├── dashboard/
│ │ ├── employee/
│ │ ├── payroll/
│ │ └── timetracker/
│ └── resources/
│ ├── credentials.txt
│ ├── employee_data.txt
│ ├── payroll_data.txt
│ ├── timelogs.txt
│ └── images/
│ ├── MotorPH Login Design.jpg
│ └── MotorPH Timetracker Design.jpg


---

## How to Run the Application

1. **Clone or download** the project from GitHub.
2. Open it in **NetBeans (with JDK 21)**.
3. Clean and Build the project:
   - From NetBeans: `Build > Clean and Build Project`
4. Run the application:
   - `Run > Run Project`
5. Login using:
   - Example credentials: `admin,admin123` (from `credentials.txt`)

---

##  Author

**Dayang Gwapa**  
Student Developer  
MotorPH Java Payroll System (2025)

---

## 📌 Notes

- Java 21 and Maven are required.
- Data is saved in `src/main/resources/` using **tab-separated values** for compatibility.
- You can customize the UI further by replacing the images in `/resources/images/`.

---

## GitHub-Ready

Because all resource files are now within `src/main/resources/`, your project is **fully functional out-of-the-box** when cloned from GitHub.


## GROUP 9 MEMBERS

1. Diane Ababao
2. Mae Ferlyn Costales
3. Jenim Domugho
4. Emelyn Maguad
5. Sherlyn Joy Malvas