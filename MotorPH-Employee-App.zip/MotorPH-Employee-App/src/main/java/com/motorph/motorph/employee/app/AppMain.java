/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.motorph.motorph.employee.app;

import com.motorph.motorph.employee.app.auth.LoginFrame;

/**
 *
 * @author DAYANG GWAPA
 */

public class AppMain {
    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(LoginFrame::new);
    }
}
