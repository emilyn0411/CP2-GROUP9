/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.motorph.motorph.employee.app.auth;

import com.motorph.motorph.employee.app.dashboard.DashboardFrame;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.nio.charset.StandardCharsets;

/**
 * Styled LoginFrame with background image
 * @author DAYANG GWAPA
 */
public class LoginFrame extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private Image backgroundImage;

    public LoginFrame() {
        setTitle("MotorPH Login");
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        try {
            backgroundImage = ImageIO.read(getClass().getResource("/images/MotorPH Login Design.jpg"));
        } catch (IOException e) {
            e.printStackTrace();
        }

        JPanel contentPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        contentPanel.setLayout(null);

        JLabel userLabel = new JLabel("Username:");
        userLabel.setForeground(Color.BLACK);
        userLabel.setBounds(300, 200, 100, 25);
        contentPanel.add(userLabel);

        usernameField = new JTextField();
        usernameField.setBounds(400, 200, 150, 25);
        contentPanel.add(usernameField);

        JLabel passLabel = new JLabel("Password:");
        passLabel.setForeground(Color.BLACK);
        passLabel.setBounds(300, 240, 100, 25);
        contentPanel.add(passLabel);

        passwordField = new JPasswordField();
        passwordField.setBounds(400, 240, 150, 25);
        contentPanel.add(passwordField);

        JButton loginBtn = new JButton("Login");
        loginBtn.setBounds(400, 280, 150, 30);
        loginBtn.addActionListener(e -> authenticate());
        contentPanel.add(loginBtn);

        add(contentPanel);
        setVisible(true);
    }

    private void authenticate() {
        String user = usernameField.getText().trim();
        String pass = new String(passwordField.getPassword()).trim();

        try (InputStream input = getClass().getClassLoader().getResourceAsStream("credentials.txt")) {
            if (input == null) {
                JOptionPane.showMessageDialog(this, "credentials.txt not found in resources!");
                return;
            }

            BufferedReader reader = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("[,\t]");
                if (parts.length >= 2 && parts[0].equals(user) && parts[1].equals(pass)) {
                    SessionManager.setLoggedInUser(user);
                    new DashboardFrame().setVisible(true);
                    dispose();
                    return;
                }
            }

            JOptionPane.showMessageDialog(this, "Invalid username or password.");
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error reading credentials.txt");
            System.out.println("USER HOME: " + System.getProperty("user.home"));
        }
    }
}
