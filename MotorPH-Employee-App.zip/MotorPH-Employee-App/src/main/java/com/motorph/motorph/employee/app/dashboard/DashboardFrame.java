/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.motorph.motorph.employee.app.dashboard;

import com.motorph.motorph.employee.app.timetracker.TimeTrackerPanel;
import com.motorph.motorph.employee.app.auth.SessionManager;
import com.motorph.motorph.employee.app.auth.LoginFrame;
import com.motorph.motorph.employee.app.employee.EmployeeListPanel;
import com.motorph.motorph.employee.app.payroll.PayrollPanel;

import javax.swing.*;
import java.awt.*;
/**
 *
 * @author DAYANG GWAPA
 */
public class DashboardFrame extends JFrame {
    public DashboardFrame() {
        setTitle("MotorPH Payroll System");
        setSize(1000, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Header with image and title
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(255, 230, 240)); // light pink background

        try {
            ImageIcon icon = new ImageIcon("MotorPH Login Dashboard.jpg");
            JLabel imageLabel = new JLabel(icon);
            headerPanel.add(imageLabel, BorderLayout.WEST);
        } catch (Exception e) {
            headerPanel.add(new JLabel("MotorPH"), BorderLayout.WEST);
        }

        JLabel titleLabel = new JLabel("MotorPH Payroll System", SwingConstants.CENTER);
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 32));
        titleLabel.setForeground(Color.BLACK);
        headerPanel.add(titleLabel, BorderLayout.CENTER);
        add(headerPanel, BorderLayout.NORTH);

        // Tabs
        JTabbedPane tabs = new JTabbedPane();
        tabs.add("Employees", new EmployeeListPanel());
        tabs.add("Time Tracker", new TimeTrackerPanel());
        tabs.add("Payroll", new PayrollPanel(true)); // enable calculation
        tabs.setFont(new Font("SansSerif", Font.PLAIN, 18));
        add(tabs, BorderLayout.CENTER);

        // Footer with logout button
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBackground(new Color(0, 51, 102)); // dark blue
        footer.setPreferredSize(new Dimension(100, 40));

        JLabel systemLabel = new JLabel("   MotorPH Payroll System", JLabel.LEFT);
        systemLabel.setForeground(Color.WHITE);
        systemLabel.setFont(new Font("SansSerif", Font.PLAIN, 14));
        footer.add(systemLabel, BorderLayout.WEST);

        JButton logoutBtn = new JButton("Logout");
        logoutBtn.setBackground(Color.WHITE);
        logoutBtn.setForeground(Color.BLACK);
        logoutBtn.setFont(new Font("SansSerif", Font.BOLD, 14));
        logoutBtn.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
        logoutBtn.setFocusPainted(false);
        logoutBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        logoutBtn.addActionListener(e -> {
            SessionManager.logout();
            new LoginFrame().setVisible(true);
            dispose();
        });

        JPanel logoutPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        logoutPanel.setOpaque(false);
        logoutPanel.add(logoutBtn);
        footer.add(logoutPanel, BorderLayout.EAST);

        add(footer, BorderLayout.SOUTH);
    }
}
