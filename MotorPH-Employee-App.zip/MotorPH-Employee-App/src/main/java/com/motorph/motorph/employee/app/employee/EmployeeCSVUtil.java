/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.motorph.motorph.employee.app.employee;

import java.io.*;
import java.util.*;

/**
 *
 * @author DAYANG GWAPA
 */
public class EmployeeCSVUtil {
    private static final String FILE_NAME = "employee_data.txt";
    private static final String SAVE_PATH = System.getProperty("user.home") + "/MotorPH/" + FILE_NAME;

    public static List<Employee> loadEmployees() {
        List<Employee> employees = new ArrayList<>();

        try (InputStream is = EmployeeCSVUtil.class.getClassLoader().getResourceAsStream(FILE_NAME);
             BufferedReader br = new BufferedReader(new InputStreamReader(Objects.requireNonNull(is)))) {

            String line;
            boolean isFirst = true;
            while ((line = br.readLine()) != null) {
                if (isFirst) { isFirst = false; continue; }
                String[] fields = line.split("\t");
                if (fields.length < 19) continue;

                Employee emp = new Employee(
                    fields[0], fields[1], fields[2], fields[3], fields[4],
                    fields[5], fields[6], fields[7], fields[8], fields[9],
                    fields[10], fields[11], fields[12],
                    Double.parseDouble(fields[13].replace(",", "")),
                    Double.parseDouble(fields[14].replace(",", "")),
                    Double.parseDouble(fields[15].replace(",", "")),
                    Double.parseDouble(fields[16].replace(",", "")),
                    Double.parseDouble(fields[17].replace(",", "")),
                    Double.parseDouble(fields[18].replace(",", ""))
                );
                employees.add(emp);
            }
        } catch (IOException | NullPointerException e) {
            e.printStackTrace();
        }

        return employees;
    }

    public static void saveEmployees(List<Employee> employees) {
        File saveDir = new File(System.getProperty("user.home") + "/MotorPH");
        if (!saveDir.exists()) {
            saveDir.mkdirs();
        }

        try (PrintWriter writer = new PrintWriter(new FileWriter(SAVE_PATH))) {
            writer.println("EmployeeID\tLastName\tFirstName\tBirthday\tAddress\tPhoneNumber\tSSS#\tPhilHealth#\tTIN#\tPagIbig#\tStatus\tPosition\tImmediateSupervisor\tBasicSalary\tRiceSubsidy\tPhoneAllowance\tClothingAllowance\tGrossSemiMonthly\tHourlyRate");
            for (Employee e : employees) {
                writer.printf("%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%.2f\t%.2f\t%.2f\t%.2f\t%.2f\t%.2f\n",
                    e.getEmpId(), e.getLastName(), e.getFirstName(), e.getBirthday(), e.getAddress(),
                    e.getPhoneNumber(), e.getSssNumber(), e.getPhilHealthNumber(), e.getTinNumber(),
                    e.getPagIbigNumber(), e.getStatus(), e.getPosition(), e.getImmediateSupervisor(),
                    e.getBasicSalary(), e.getRiceSubsidy(), e.getPhoneAllowance(),
                    e.getClothingAllowance(), e.getGrossSemiMonthlyRate(), e.getHourlyRate()
                );
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void addEmployee(Employee employee) {
        List<Employee> employees = loadEmployees();
        employees.add(employee);
        saveEmployees(employees);
    }

    public static void updateEmployee(Employee updated) {
        List<Employee> employees = loadEmployees();
        for (int i = 0; i < employees.size(); i++) {
            if (employees.get(i).getEmpId().equals(updated.getEmpId())) {
                employees.set(i, updated);
                break;
            }
        }
        saveEmployees(employees);
    }

    public static void deleteEmployee(String empId) {
        List<Employee> employees = loadEmployees();
        employees.removeIf(e -> e.getEmpId().equals(empId));
        saveEmployees(employees);
    }
}