/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.motorph.motorph.employee.app.employee;

import javax.swing.*;
import java.awt.*;

/**
 *
 * @author DAYANG GWAPA
 */
public class EmployeeForm extends JPanel {
    private JTextField empIdField;
    private JTextField firstNameField;
    private JTextField lastNameField;
    private JTextField birthdayField;
    private JTextField addressField;
    private JTextField phoneNumberField;
    private JTextField sssField;
    private JTextField philHealthField;
    private JTextField tinField;
    private JTextField pagIbigField;
    private JTextField statusField;
    private JTextField positionField;
    private JTextField supervisorField;

    private JTextField basicSalaryField;
    private JTextField riceField;
    private JTextField phoneField;
    private JTextField clothingField;
    private JTextField grossField;
    private JTextField hourlyField;

    private Employee employee;

    public EmployeeForm(Employee employee) {
        this.employee = employee;

        setLayout(new GridLayout(0, 2, 5, 5));

        empIdField = new JTextField();
        lastNameField = new JTextField();
        firstNameField = new JTextField();
        birthdayField = new JTextField();
        addressField = new JTextField();
        phoneNumberField = new JTextField();
        sssField = new JTextField();
        philHealthField = new JTextField();
        tinField = new JTextField();
        pagIbigField = new JTextField();
        statusField = new JTextField();
        positionField = new JTextField();
        supervisorField = new JTextField();

        basicSalaryField = new JTextField();
        riceField = new JTextField();
        phoneField = new JTextField();
        clothingField = new JTextField();
        grossField = new JTextField();
        hourlyField = new JTextField();

        add(new JLabel("Employee ID:")); add(empIdField);
        add(new JLabel("Last Name:")); add(lastNameField);
        add(new JLabel("First Name:")); add(firstNameField);
        add(new JLabel("Birthday:")); add(birthdayField);
        add(new JLabel("Address:")); add(addressField);
        add(new JLabel("Phone Number:")); add(phoneNumberField);
        add(new JLabel("SSS #:")); add(sssField);
        add(new JLabel("PhilHealth #:")); add(philHealthField);
        add(new JLabel("TIN #:")); add(tinField);
        add(new JLabel("Pag-ibig #:")); add(pagIbigField);
        add(new JLabel("Status:")); add(statusField);
        add(new JLabel("Position:")); add(positionField);
        add(new JLabel("Immediate Supervisor:")); add(supervisorField);
        add(new JLabel("Basic Salary:")); add(basicSalaryField);
        add(new JLabel("Rice Subsidy:")); add(riceField);
        add(new JLabel("Phone Allowance:")); add(phoneField);
        add(new JLabel("Clothing Allowance:")); add(clothingField);
        add(new JLabel("Gross Semi-monthly Rate:")); add(grossField);
        add(new JLabel("Hourly Rate:")); add(hourlyField);

        if (employee != null) {
            empIdField.setText(employee.getEmpId()); empIdField.setEditable(false);
            lastNameField.setText(employee.getLastName());
            firstNameField.setText(employee.getFirstName());
            birthdayField.setText(employee.getBirthday());
            addressField.setText(employee.getAddress());
            phoneNumberField.setText(employee.getPhoneNumber());
            sssField.setText(employee.getSssNumber());
            philHealthField.setText(employee.getPhilHealthNumber());
            tinField.setText(employee.getTinNumber());
            pagIbigField.setText(employee.getPagIbigNumber());
            statusField.setText(employee.getStatus());
            positionField.setText(employee.getPosition());
            supervisorField.setText(employee.getImmediateSupervisor());
            basicSalaryField.setText(String.valueOf(employee.getBasicSalary()));
            riceField.setText(String.valueOf(employee.getRiceSubsidy()));
            phoneField.setText(String.valueOf(employee.getPhoneAllowance()));
            clothingField.setText(String.valueOf(employee.getClothingAllowance()));
            grossField.setText(String.valueOf(employee.getGrossSemiMonthlyRate()));
            hourlyField.setText(String.valueOf(employee.getHourlyRate()));
        }
    }

    public boolean showDialog(Component parent, String title) {
        int result = JOptionPane.showConfirmDialog(parent, this, title, JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            try {
                employee = new Employee(
                    empIdField.getText().trim(),
                    lastNameField.getText().trim(),
                    firstNameField.getText().trim(),
                    birthdayField.getText().trim(),
                    addressField.getText().trim(),
                    phoneNumberField.getText().trim(),
                    sssField.getText().trim(),
                    philHealthField.getText().trim(),
                    tinField.getText().trim(),
                    pagIbigField.getText().trim(),
                    statusField.getText().trim(),
                    positionField.getText().trim(),
                    supervisorField.getText().trim(),
                    Double.parseDouble(basicSalaryField.getText().trim()),
                    Double.parseDouble(riceField.getText().trim()),
                    Double.parseDouble(phoneField.getText().trim()),
                    Double.parseDouble(clothingField.getText().trim()),
                    Double.parseDouble(grossField.getText().trim()),
                    Double.parseDouble(hourlyField.getText().trim())
                );
                return true;
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(parent, "Please enter valid numbers for salary and allowance fields.");
                return false;
            }
        }
        return false;
    }

    public Employee getEmployee() {
        return employee;
    }
}