/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.motorph.motorph.employee.app.employee;


import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import com.motorph.motorph.employee.app.payroll.PayrollCalculator;
/**
 * Styled Employee List Panel for MotorPH
 * with motorcycle theme and pink-blue design
 *
 * @author DAYANG GWAPA
 */
public class EmployeeListPanel extends JPanel {
    private JTable table;
    private DefaultTableModel tableModel;
    private JButton addButton, editButton, deleteButton, updateButton;

    public EmployeeListPanel() {
        setLayout(new BorderLayout());

        // Header
        JLabel header = new JLabel("Employee List", SwingConstants.CENTER);
        header.setFont(new Font("SansSerif", Font.BOLD, 26));
        header.setForeground(Color.WHITE);
        header.setOpaque(true);
        header.setBackground(new Color(0, 51, 102));
        header.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        add(header, BorderLayout.NORTH);

        // Table setup
        tableModel = new DefaultTableModel(new String[] {
            "Employee ID", "Last Name", "First Name", "Position", "Basic Salary", "Gross Pay", "Deductions", "Net Pay"
        }, 0);
        table = new JTable(tableModel);
        table.setFont(new Font("SansSerif", Font.PLAIN, 14));
        table.setRowHeight(24);
        loadTable();

        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBackground(new Color(255, 230, 240));
        addButton = new JButton("Add");
        editButton = new JButton("Edit");
        deleteButton = new JButton("Delete");
        updateButton = new JButton("Update Payroll");

        styleButton(addButton);
        styleButton(editButton);
        styleButton(deleteButton);
        styleButton(updateButton);

        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(updateButton);

        add(buttonPanel, BorderLayout.SOUTH);

        // Button actions
        addButton.addActionListener(e -> onAdd());
        editButton.addActionListener(e -> onEdit());
        deleteButton.addActionListener(e -> onDelete());
        updateButton.addActionListener(e -> onUpdate());
    }

    private void styleButton(JButton button) {
        button.setFont(new Font("SansSerif", Font.BOLD, 14));
        button.setBackground(new Color(255, 255, 255));
        button.setForeground(new Color(0, 51, 102));
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createLineBorder(new Color(0, 51, 102)));
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }

    private void loadTable() {
        tableModel.setRowCount(0);
        List<Employee> employees = EmployeeCSVUtil.loadEmployees();
        for (Employee e : employees) {
            double gross = PayrollCalculator.calculateGross(e);
            double deductions = PayrollCalculator.calculateDeductions(e);
            double net = PayrollCalculator.calculateNet(e);
            tableModel.addRow(new Object[] {
                e.getEmpId(), e.getLastName(), e.getFirstName(), e.getPosition(),
                e.getBasicSalary(), gross, deductions, net
            });
        }
    }

    private void onAdd() {
        EmployeeForm form = new EmployeeForm(null);
        if (form.showDialog(this, "Add Employee")) {
            EmployeeCSVUtil.addEmployee(form.getEmployee());
            loadTable();
        }
    }

    private void onEdit() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a row to edit.");
            return;
        }

        String empId = tableModel.getValueAt(selectedRow, 0).toString();
        List<Employee> employees = EmployeeCSVUtil.loadEmployees();
        Employee toEdit = null;
        for (Employee e : employees) {
            if (e.getEmpId().equals(empId)) {
                toEdit = e;
                break;
            }
        }

        if (toEdit != null) {
            EmployeeForm form = new EmployeeForm(toEdit);
            if (form.showDialog(this, "Edit Employee")) {
                EmployeeCSVUtil.updateEmployee(form.getEmployee());
                loadTable();
            }
        }
    }

    private void onDelete() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a row to delete.");
            return;
        }

        String empId = tableModel.getValueAt(selectedRow, 0).toString();
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete employee ID " + empId + "?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            EmployeeCSVUtil.deleteEmployee(empId);
            loadTable();
        }
    }

    private void onUpdate() {
        loadTable();
        JOptionPane.showMessageDialog(this, "Employee payroll data refreshed.");
    }
}