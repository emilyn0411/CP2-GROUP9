/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.motorph.motorph.employee.app.payroll;

import java.io.*;
import java.util.*;

/**
 *
 * @author DAYANG GWAPA
 */
public class PayrollCSVUtil {
    private static final String PAYROLL_FILE = "payroll_raw_data.tsv";

    public static List<PayrollRecord> loadPayrollData() {
        List<PayrollRecord> records = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(PAYROLL_FILE))) {
            String line;
            boolean isFirstLine = true;
            while ((line = reader.readLine()) != null) {
                if (isFirstLine) {
                    isFirstLine = false;
                    continue; // skip header
                }
                String[] fields = line.split("\t");
                if (fields.length >= 8) {
                    records.add(new PayrollRecord(
                        fields[0], // ID
                        fields[1], // Name
                        fields[2], // Period
                        Double.parseDouble(fields[3]), // Basic
                        Double.parseDouble(fields[4]), // Rice
                        Double.parseDouble(fields[5]), // Phone
                        Double.parseDouble(fields[6]), // Clothing
                        Double.parseDouble(fields[7])  // Deductions
                    ));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return records;
    }
}
