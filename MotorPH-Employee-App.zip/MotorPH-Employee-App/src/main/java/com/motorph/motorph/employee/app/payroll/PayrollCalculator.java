/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.motorph.motorph.employee.app.payroll;

import com.motorph.motorph.employee.app.employee.Employee;
/**
 *
 * @author DAYANG GWAPA
 */
public class PayrollCalculator {
    public static double calculateGross(Employee e) {
        return e.getBasicSalary() + e.getRiceSubsidy() + e.getPhoneAllowance() + e.getClothingAllowance();
    }

    public static double calculateDeductions(Employee e) {
        return e.getSssDeduction() + e.getPhilHealthDeduction() + e.getPagIbigDeduction() + e.getTaxDeduction();
    }

    public static double calculateNet(Employee e) {
        return calculateGross(e) - calculateDeductions(e);
    }
}