/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.motorph.motorph.employee.app.payroll;

import com.motorph.motorph.employee.app.employee.Employee;
import com.motorph.motorph.employee.app.employee.EmployeeCSVUtil;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
/**
 *
 * @author DAYANG GWAPA
 */
/**
 * Styled Payroll Panel for MotorPH
 * with Filipino flag character background
 */
public class PayrollPanel extends JPanel {
    public PayrollPanel(boolean performCalculation) {
        setLayout(new BorderLayout());

        // Header with character holding PH flag
        JLabel header = new JLabel("Payroll Summary", SwingConstants.CENTER);
        header.setFont(new Font("SansSerif", Font.BOLD, 26));
        header.setForeground(Color.WHITE);
        header.setOpaque(true);
        header.setBackground(new Color(0, 51, 102));
        header.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        add(header, BorderLayout.NORTH);

        // Table setup
        String[] columns = {
            "ID", "Name", "Basic Salary", "Gross Pay", "Deductions", "Net Pay"
        };
        DefaultTableModel model = new DefaultTableModel(columns, 0);

        List<Employee> employees = EmployeeCSVUtil.loadEmployees();
        for (Employee e : employees) {
            String name = e.getFullName();
            double gross = PayrollCalculator.calculateGross(e);
            double deductions = PayrollCalculator.calculateDeductions(e);
            double net = PayrollCalculator.calculateNet(e);

            model.addRow(new Object[] {
                e.getEmpId(),
                name,
                String.format("%.2f", e.getBasicSalary()),
                String.format("%.2f", gross),
                String.format("%.2f", deductions),
                String.format("%.2f", net)
            });
        }

        JTable table = new JTable(model);
        table.setFont(new Font("SansSerif", Font.PLAIN, 14));
        table.setRowHeight(24);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // Background and border styling
        setBackground(new Color(255, 230, 240));
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(0, 51, 102), 2));
    }
}