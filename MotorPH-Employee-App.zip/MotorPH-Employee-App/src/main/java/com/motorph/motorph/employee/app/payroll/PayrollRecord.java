/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.motorph.motorph.employee.app.payroll;

/**
 *
 * @author DAYANG GWAPA
 */
public class PayrollRecord {
    private String id;
    private String name;
    private String period;
    private double basic;
    private double rice;
    private double phone;
    private double clothing;
    private double deductions;

    public PayrollRecord(String id, String name, String period, double basic, double rice, double phone, double clothing, double deductions) {
        this.id = id;
        this.name = name;
        this.period = period;
        this.basic = basic;
        this.rice = rice;
        this.phone = phone;
        this.clothing = clothing;
        this.deductions = deductions;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public String getPeriod() { return period; }
    public double getBasic() { return basic; }
    public double getRice() { return rice; }
    public double getPhone() { return phone; }
    public double getClothing() { return clothing; }
    public double getDeductions() { return deductions; }
}