/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.motorph.motorph.employee.app.timetracker;

import com.motorph.motorph.employee.app.auth.SessionManager;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.text.*;
import java.util.*;
import javax.swing.Timer;
/**
 * TimeTrackerPanel with full background image (motorcycle theme)
 * and 12/24-hour toggle
 *
 * @author DAYANG GWAPA
 */
public class TimeTrackerPanel extends JPanel {
    private JLabel clockLabel;
    private JButton toggleButton, clockInBtn, clockOutBtn;
    private boolean is24Hour = true;
    private Timer timer;
    private Image backgroundImage;

    public TimeTrackerPanel() {
        try {
            backgroundImage = ImageIO.read(getClass().getResource("/images/MotorPH Timetracker Design.jpg"));
        } catch (IOException e) {
            e.printStackTrace();
        }

        setLayout(null);

        clockLabel = new JLabel("", JLabel.CENTER);
        clockLabel.setFont(new Font("Monospaced", Font.BOLD, 40));
        clockLabel.setForeground(Color.WHITE);
        clockLabel.setBounds(250, 50, 300, 50);
        add(clockLabel);

        toggleButton = new JButton("Switch to 12-Hour");
        toggleButton.setBounds(560, 60, 170, 30);
        add(toggleButton);

        clockInBtn = new JButton("Clock In");
        clockInBtn.setBounds(250, 150, 120, 40);
        add(clockInBtn);

        clockOutBtn = new JButton("Clock Out");
        clockOutBtn.setBounds(430, 150, 120, 40);
        add(clockOutBtn);

        toggleButton.addActionListener(e -> {
            is24Hour = !is24Hour;
            toggleButton.setText(is24Hour ? "Switch to 12-Hour" : "Switch to 24-Hour");
        });

        timer = new Timer(1000, e -> updateClock());
        timer.start();

        clockInBtn.addActionListener(e -> logTime("IN"));
        clockOutBtn.addActionListener(e -> logTime("OUT"));
    }

    private void updateClock() {
        Date now = new Date();
        DateFormat format = is24Hour ? new SimpleDateFormat("HH:mm:ss") : new SimpleDateFormat("hh:mm:ss a");
        clockLabel.setText(format.format(now));
    }

    private void logTime(String type) {
        try (PrintWriter out = new PrintWriter(new FileWriter("src/main/resources/timelogs.txt", true))) {
            String timeStamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
            out.println(SessionManager.getLoggedInUser() + "\t" + type + "\t" + timeStamp);
            JOptionPane.showMessageDialog(this, type + " recorded at " + timeStamp);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (backgroundImage != null) {
            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
        }
    }
}