package com.motorph;

public class Main {
    public static void main(String[] args) {
        new LoginScreen();
    }
}