package com.mycompany.motorphapps.Dashboard;

import com.mycompany.motorphapps.Panel.PayrollPanel;
import com.mycompany.motorphapps.All.AllEmployeesPanel;
import com.mycompany.motorphapps.employee.EmployeeInfoPanel;
import com.mycompany.motorphapps.Login.LoginScreen;
import com.mycompany.motorphapps.timetracker.TimeTracker;
import com.mycompany.motorphapps.attendance.AttendancePanel;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Dashboard extends JFrame {

    public Dashboard(String employeeID, String role) {
        setTitle("MotorPH Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 650);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JTabbedPane tabbedPane = new JTabbedPane();

        // My Info Panel
        tabbedPane.addTab("My Info", new EmployeeInfoPanel(employeeID));

        // Time Tracker Panel (for users only)
        if (!role.equalsIgnoreCase("admin")) {
            tabbedPane.addTab("Time Tracker", new TimeTracker(employeeID));
        }

        // Attendance Panel (both roles)
        tabbedPane.addTab("Attendance", new AttendancePanel(employeeID, role));

        // Payroll Panel
        tabbedPane.addTab("Payroll", new PayrollPanel(employeeID, role));

        // All Employees Panel (for admin only)
        if (role.equalsIgnoreCase("admin")) {
            tabbedPane.addTab("All Employees", new AllEmployeesPanel());
        }

        // Add tabbedPane to center
        add(tabbedPane, BorderLayout.CENTER);

        // Create a logout button at the bottom
        JButton logoutButton = new JButton("Logout");
        logoutButton.setForeground(Color.RED);
        logoutButton.addActionListener(e -> {
            int confirmed = JOptionPane.showConfirmDialog(this, "Are you sure you want to log out?", "Logout", JOptionPane.YES_NO_OPTION);
            if (confirmed == JOptionPane.YES_OPTION) {
                dispose();
                new LoginScreen(); // redirect to login
            }
        });

        // Add the logout button in a panel at the bottom
        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
        bottomPanel.add(logoutButton);
        add(bottomPanel, BorderLayout.SOUTH);

        setVisible(true);
    }
}
