package com.mycompany.motorphapps.attendance;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class AttendancePanel extends JPanel {
    private final DefaultTableModel model;
    private final JTable table;
    private final String employeeID;
    private final String role;

    public AttendancePanel(String employeeID, String role) {
        this.employeeID = employeeID;
        this.role = role;
        setLayout(new BorderLayout());

        String[] columns = {"Employee ID", "Name", "Date", "Time In", "Time Out"};
        model = new DefaultTableModel(columns, 0);
        table = new JTable(model);

        loadAttendanceData();

        JButton timeInBtn = new JButton("Time In");
        JButton timeOutBtn = new JButton("Time Out");

        timeInBtn.addActionListener(e -> recordTime("in"));
        timeOutBtn.addActionListener(e -> recordTime("out"));

        JPanel btnPanel = new JPanel();
        btnPanel.add(timeInBtn);
        btnPanel.add(timeOutBtn);

        add(btnPanel, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);
    }

    private void recordTime(String type) {
        String date = new SimpleDateFormat("MM/dd/yyyy").format(new Date());
        String time = new SimpleDateFormat("HH:mm").format(new Date());

        try {
            File file = new File("attendance_log.txt");
            File tempFile = new File("temp_attendance_log.txt");
            boolean updated = false;

            try (
                BufferedReader br = new BufferedReader(new FileReader(file));
                BufferedWriter bw = new BufferedWriter(new FileWriter(tempFile))
            ) {
                String line;
                while ((line = br.readLine()) != null) {
                    String[] parts = line.split("\t");
                    if (parts.length >= 6 && parts[0].equals(employeeID) && parts[3].equals(date)) {
                        if (type.equals("out")) {
                            line = String.join("\t", parts[0], parts[1], parts[2], parts[3], parts[4], time);
                            updated = true;
                        }
                    }
                    bw.write(line);
                    bw.newLine();
                }

                if (!updated && type.equals("in")) {
                    String fullName = getEmployeeName(employeeID);
                    String[] nameParts = fullName.split(" ", 2);
                    String lastName = nameParts.length > 1 ? nameParts[1] : "";
                    String firstName = nameParts[0];
                    bw.write(String.join("\t", employeeID, lastName, firstName, date, time, "-"));
                    bw.newLine();
                }
            }

            file.delete();
            tempFile.renameTo(file);

            loadAttendanceData();
        } catch (IOException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error recording time.");
        }
    }

    private void loadAttendanceData() {
        model.setRowCount(0);
        try (BufferedReader br = new BufferedReader(new FileReader("attendance_log.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] row = line.split("\t");
                if (row.length == 6) {
                    boolean isAdmin = role.equals("admin");
                    boolean isOwner = row[0].equals(employeeID);
                    if (isAdmin || isOwner) {
                        model.addRow(row);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String getEmployeeName(String empId) {
        try (BufferedReader br = new BufferedReader(new FileReader("employee_data.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split("\t");
                if (data.length >= 3 && data[0].equals(empId)) {
                    return data[2] + " " + data[1]; // FirstName LastName
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "Unknown";
    }
} 
