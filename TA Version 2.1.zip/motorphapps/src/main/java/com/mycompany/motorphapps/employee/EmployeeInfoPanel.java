package com.mycompany.motorphapps.employee;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;


public class EmployeeInfoPanel extends JPanel {
    private BufferedImage backgroundImage;
    private BufferedImage profileImage; // optional

    // Column index constants (tab-separated file)
    private static final int IDX_EMP_ID = 0;
    private static final int IDX_LAST   = 1;
    private static final int IDX_FIRST  = 2;
    private static final int IDX_BIRTH  = 3;
    private static final int IDX_ADDR   = 4;
    private static final int IDX_PHONE  = 5;
    private static final int IDX_SSS    = 6;
    private static final int IDX_PHIL   = 7;
    private static final int IDX_TIN    = 8;
    private static final int IDX_PAGIBIG= 9;
    private static final int IDX_STATUS =10;
    private static final int IDX_POS    =11;
    private static final int IDX_SUP    =12;
    private static final int IDX_BASIC  =13;
    private static final int IDX_RICE   =14;
    private static final int IDX_PHONEA =15;
    private static final int IDX_CLOTH  =16;
    private static final int IDX_GROSS  =17;
    private static final int IDX_HOURLY =18;

    /** Holds parsed columns for the matched employee row. */
    private List<String> employeeCols = new ArrayList<>();

    public EmployeeInfoPanel(String employeeID) {
        // Load background
        backgroundImage = loadImageFromResource("/images/MotorPH Timetracker Design.jpg");
        // Try to load profile image (optional); provide your own image path or leave null
        profileImage = loadImageFromResource("/images/adminProfile.jpg");

        setLayout(new BorderLayout());
        setOpaque(false);

        // Title
        JLabel title = new JLabel("My Info", SwingConstants.CENTER);
        title.setFont(new Font("SansSerif", Font.BOLD, 20));
        title.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));
        title.setForeground(Color.BLACK);
        add(title, BorderLayout.NORTH);

        // Card container (semi-transparent white)
        JPanel card = new JPanel(new BorderLayout(20, 0)) { // gap for profile area
            @Override public boolean isOpaque() { return false; }
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setColor(new Color(255, 255, 255, 200));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        card.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 0));

        // LEFT: profile image (optional)
        card.add(createProfilePanel(), BorderLayout.WEST);

        // CENTER: grouped employee info panels
        JPanel groupedPanel = new JPanel();
        groupedPanel.setLayout(new BoxLayout(groupedPanel, BoxLayout.Y_AXIS));
        groupedPanel.setOpaque(false);

        // Load employee data before building UI rows
        loadEmployeeRow(employeeID);

        groupedPanel.add(buildSectionPersonal());
        groupedPanel.add(Box.createVerticalStrut(15));
        groupedPanel.add(buildSectionGovIDs());
        groupedPanel.add(Box.createVerticalStrut(15));
        groupedPanel.add(buildSectionComp());

        card.add(groupedPanel, BorderLayout.CENTER);
        add(card, BorderLayout.CENTER);
    }

    // ------------------------------------------------------------------
    // UI SECTIONS
    // ------------------------------------------------------------------
    private JPanel buildSectionPersonal() {
        JPanel p = createSectionPanel("Personal Info");
        addRow(p, "Employee ID", getCol(IDX_EMP_ID));
        addRow(p, "First Name", getCol(IDX_FIRST));
        addRow(p, "Last Name",  getCol(IDX_LAST));
        addRow(p, "Birthday",   getCol(IDX_BIRTH));
        addRow(p, "Address",    getCol(IDX_ADDR));
        addRow(p, "Phone",      getCol(IDX_PHONE));
        addRow(p, "Status",     getCol(IDX_STATUS));
        return p;
    }

    private JPanel buildSectionGovIDs() {
        JPanel p = createSectionPanel("Government IDs");
        addRow(p, "SSS #",       getCol(IDX_SSS));
        addRow(p, "PhilHealth #",getCol(IDX_PHIL));
        addRow(p, "TIN #",       getCol(IDX_TIN));
        addRow(p, "Pag-ibig #",  getCol(IDX_PAGIBIG));
        return p;
    }

    private JPanel buildSectionComp() {
        JPanel p = createSectionPanel("Compensation");
        addRow(p, "Position",            getCol(IDX_POS));
        addRow(p, "Immediate Supervisor",getCol(IDX_SUP));
        addRow(p, "Basic Salary",        getCol(IDX_BASIC));
        addRow(p, "Rice Subsidy",        getCol(IDX_RICE));
        addRow(p, "Phone Allowance",     getCol(IDX_PHONEA));
        addRow(p, "Clothing Allowance",  getCol(IDX_CLOTH));
        addRow(p, "Gross Semi-monthly",  getCol(IDX_GROSS));
        addRow(p, "Hourly Rate",         getCol(IDX_HOURLY));
        return p;
    }

    /** Creates a section with a titled border and 2-column grid. */
    private JPanel createSectionPanel(String title) {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder(BorderFactory.createLineBorder(new Color(0,0,0,50)), title,
                        TitledBorder.LEFT, TitledBorder.TOP,
                        new Font("SansSerif", Font.BOLD, 14), Color.BLACK),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        return panel;
    }

    /** Adds one label/value row to a GridBagLayout section panel. */
    private void addRow(JPanel panel, String labelText, String valueText) {
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(2,2,2,2);
        gbc.anchor = GridBagConstraints.WEST;

        JLabel label = new JLabel(labelText + ": ");
        label.setFont(new Font("SansSerif", Font.PLAIN, 14));
        label.setForeground(Color.BLACK);
        gbc.gridx = 0; gbc.gridy = panel.getComponentCount()/2; // each row adds 2 comps
        panel.add(label, gbc);

        JLabel value = new JLabel(valueText);
        value.setFont(new Font("SansSerif", Font.BOLD, 14));
        value.setForeground(Color.DARK_GRAY);
        gbc.gridx = 1;
        panel.add(value, gbc);
    }

    // ------------------------------------------------------------------
    // PROFILE IMAGE PANEL
    // ------------------------------------------------------------------
    private JComponent createProfilePanel() {
        JPanel p = new JPanel() {
            @Override public Dimension getPreferredSize() { return new Dimension(140, 140); }
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (profileImage != null) {
                    int w = getWidth();
                    int h = getHeight();
                    Image scaled = profileImage.getScaledInstance(Math.min(w,120), Math.min(h,120), Image.SCALE_SMOOTH);
                    int x = (w - scaled.getWidth(this)) / 2;
                    int y = (h - scaled.getHeight(this)) / 2;
                    g.drawImage(scaled, x, y, this);
                } else {
                    // fallback placeholder
                    g.setColor(new Color(200,200,200));
                    g.fillOval(20, 20, 100, 100);
                    g.setColor(Color.GRAY);
                    g.drawOval(20, 20, 100, 100);
                    g.setFont(new Font("SansSerif", Font.BOLD, 16));
                    FontMetrics fm = g.getFontMetrics();
                    String txt = "N/A";
                    int tx = 20 + (100 - fm.stringWidth(txt)) / 2;
                    int ty = 20 + (100 + fm.getAscent()) / 2 - 4;
                    g.drawString(txt, tx, ty);
                }
            }
        };
        p.setOpaque(false);
        return p;
    }

    // ------------------------------------------------------------------
    // DATA LOADING
    // ------------------------------------------------------------------
    private void loadEmployeeRow(String employeeID) {
        // Try classpath resource first
        boolean loaded = loadEmployeeRowFromResource("/data/employee_data.txt", employeeID);
        if (!loaded) {
            // Fall back to a file in the working directory
            loadEmployeeRowFromFile(new File("employee_data.txt"), employeeID);
        }
    }

    private boolean loadEmployeeRowFromResource(String resourcePath, String employeeID) {
        InputStream in = getClass().getResourceAsStream(resourcePath);
        if (in == null) {
            return false;
        }
        try (BufferedReader br = new BufferedReader(new InputStreamReader(in))) {
            return scanReaderForEmployee(br, employeeID);
        } catch (IOException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    private boolean loadEmployeeRowFromFile(File file, String employeeID) {
        if (!file.exists()) {
            return false;
        }
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            return scanReaderForEmployee(br, employeeID);
        } catch (IOException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    private boolean scanReaderForEmployee(BufferedReader br, String employeeID) throws IOException {
        String line;
        while ((line = br.readLine()) != null) {
            String[] data = line.split("\t");
            if (data.length > 0 && data[0].equals(employeeID)) {
                employeeCols.clear();
                for (String d : data) {
                    employeeCols.add(d.trim());
                }
                return true;
            }
        }
        return false;
    }

    private String getCol(int idx) {
        if (idx < employeeCols.size()) {
            String v = employeeCols.get(idx);
            return (v == null || v.isEmpty()) ? "N/A" : v;
        }
        return "N/A";
    }

    // ------------------------------------------------------------------
    // IMAGE LOADING UTIL
    // ------------------------------------------------------------------
    private BufferedImage loadImageFromResource(String path) {
        try {
            URL url = getClass().getResource(path);
            if (url != null) {
                return ImageIO.read(url);
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return null;
    }

    // ------------------------------------------------------------------
    // PAINT BACKGROUND
    // ------------------------------------------------------------------
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (backgroundImage != null) {
            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
        }
    }
}
