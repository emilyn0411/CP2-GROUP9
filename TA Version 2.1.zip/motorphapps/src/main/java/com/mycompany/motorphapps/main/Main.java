package com.mycompany.motorphapps.main;

import com.mycompany.motorphapps.Login.LoginScreen;


import com.mycompany.motorphapps.Login.LoginScreen;

public class Main {
    public static void main(String[] args) {
        new LoginScreen(); // Start the application from here
    }
}