package com.mycompany.motorph;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Authenticator {
    public static String authenticate(String employeeID, String password) {
        String filePath = "credentials.txt"; 
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;

            while ((line = br.readLine()) != null) {
                
                String[] values = line.split(",");

                if (values.length != 3) continue; 

                String storedID = values[0].trim();
                String storedPassword = values[1].trim();
                String role = values[2].trim();

                if (employeeID.equals(storedID) && password.equals(storedPassword)) {
                    return role;
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading credentials file: " + e.getMessage());
        }

        return null; // invalid credentials
    }
}