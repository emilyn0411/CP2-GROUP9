package com.mycompany.motorph;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import javax.swing.*;

public class Dashboard extends JFrame {

    public Dashboard(String employeeID, String role) {
        setTitle("MotorPH Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 600);
        setLocationRelativeTo(null);

        // Create main panel with BorderLayout
        JPanel mainPanel = new JPanel(new BorderLayout());

        // Create tabbed pane
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.addTab("My Info", new EmployeeInfoPanel(employeeID));

        if (!role.equalsIgnoreCase("admin")) {
            tabbedPane.addTab("Time Tracker", new TimeTracker(employeeID));
        }

        tabbedPane.addTab("Payroll", new PayrollPanel(employeeID, role));

        if (role.equalsIgnoreCase("admin")) {
            tabbedPane.addTab("All Employees", new AllEmployeesPanel());
        }

        // Create a bottom panel for the logout button
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton logoutButton = new JButton("Logout");
        logoutButton.setForeground(Color.RED);

        // Add action listener for logout
        logoutButton.addActionListener((ActionEvent e) -> {
            int confirmed = JOptionPane.showConfirmDialog(
                this, "Are you sure you want to log out?", "Logout", JOptionPane.YES_NO_OPTION
            );
            if (confirmed == JOptionPane.YES_OPTION) {
                dispose();
                new LoginScreen(); // Redirect to login screen
            }
        });

        // Add logout button to bottom panel
        bottomPanel.add(logoutButton);

        // Add components to main panel
        mainPanel.add(tabbedPane, BorderLayout.CENTER);
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        // Add main panel to frame
        add(mainPanel);
        setVisible(true);
    }
}