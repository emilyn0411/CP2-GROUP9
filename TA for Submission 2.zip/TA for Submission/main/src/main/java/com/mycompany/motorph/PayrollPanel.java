package com.mycompany.motorph;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import javax.imageio.ImageIO;

public class PayrollPanel extends JPanel {
    private DefaultTableModel model;
    private JTable table;
    private JTextField filterIdField;
    private JComboBox<String> periodComboBox;
    private JComboBox<String> monthComboBox;
    private String employeeID;
    private String role;

    public PayrollPanel(String employeeID, String role) {
        this.employeeID = employeeID;
        this.role = role;
        setLayout(new BorderLayout());

        String[] columns = {"Employee ID", "Employee Name", "Period", "Gross Pay", "Deductions", "Net Pay"};
        model = new DefaultTableModel(columns, 0);
        table = new JTable(model);

        try {
            BufferedImage bgImage = ImageIO.read(getClass().getResource("/images/MotorPH Login Design.jpg"));
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (role.equals("admin")) {
            JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
            filterPanel.add(new JLabel("Filter by Employee ID:"));
            filterIdField = new JTextField(10);
            filterPanel.add(filterIdField);

            filterPanel.add(new JLabel("Cutoff Period:"));
            periodComboBox = new JComboBox<>(new String[]{"All", "15", "30"});
            filterPanel.add(periodComboBox);

            filterPanel.add(new JLabel("Month:"));
            monthComboBox = new JComboBox<>(new String[]{
                "All", "January", "February", "March", "April", "May", "June",
                "July", "August", "September", "October", "November", "December"
            });
            filterPanel.add(monthComboBox);

            JButton applyFilterBtn = new JButton("Apply Filters");
            filterPanel.add(applyFilterBtn);
            applyFilterBtn.addActionListener(e -> applyFilters());
            add(filterPanel, BorderLayout.NORTH);

            JPanel calcPanel = new JPanel(new GridLayout(0, 2, 5, 5));
            calcPanel.setBorder(BorderFactory.createTitledBorder("Calculate Payroll"));

            JTextField empIdField = new JTextField();
            JTextField nameField = new JTextField();
            JTextField hoursField = new JTextField();
            JTextField rateField = new JTextField();
            JComboBox<String> periodInput = new JComboBox<>(new String[]{"15", "30"});
            JComboBox<String> cutoffMonthInput = new JComboBox<>(new String[]{
                "January", "February", "March", "April", "May", "June",
                "July", "August", "September", "October", "November", "December"
            });

            calcPanel.add(new JLabel("Employee ID:"));
            calcPanel.add(empIdField);
            calcPanel.add(new JLabel("Employee Name:"));
            calcPanel.add(nameField);
            calcPanel.add(new JLabel("Hours Worked:"));
            calcPanel.add(hoursField);
            calcPanel.add(new JLabel("Rate per Hour:"));
            calcPanel.add(rateField);
            calcPanel.add(new JLabel("Cutoff Period:"));
            calcPanel.add(periodInput);
            calcPanel.add(new JLabel("Select Month:"));
            calcPanel.add(cutoffMonthInput);

            JButton autoFetchBtn = new JButton("Auto-Fetch Hours");
            JButton calculateBtn = new JButton("Calculate & Save");

            calcPanel.add(autoFetchBtn);
            calcPanel.add(calculateBtn);

            autoFetchBtn.addActionListener(e -> {
                try {
                    String id = empIdField.getText().trim();
                    String period = (String) periodInput.getSelectedItem();
                    int monthIndex = cutoffMonthInput.getSelectedIndex();

                    String fullName = getEmployeeFullName(id);
                    nameField.setText(fullName);

                    double hours = calculateHoursFromLog(id, period, monthIndex);
                    hoursField.setText(String.format("%.2f", hours));

                    double rate = getHourlyRate(id);
                    rateField.setText(String.format("%.2f", rate));
                } catch (Exception ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(this, "Error fetching employee data: " + ex.getMessage());
                }
            });

            calculateBtn.addActionListener(e -> {
                try {
                    String id = empIdField.getText().trim();
                    String name = nameField.getText().trim();
                    String period = (String) periodInput.getSelectedItem();
                    String month = (String) cutoffMonthInput.getSelectedItem();
                    double hours = Double.parseDouble(hoursField.getText().trim());
                    double rate = Double.parseDouble(rateField.getText().trim());
                    String fullPeriod = month + "-" + period;

                    calculateAndSavePayroll(id, name, fullPeriod, hours, rate);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "Please enter valid numeric values.");
                }
            });

            add(calcPanel, BorderLayout.SOUTH);
        }

        add(new JScrollPane(table), BorderLayout.CENTER);
        loadPayrollData();
    }

    private void loadPayrollData() {
        model.setRowCount(0);
        try (BufferedReader br = new BufferedReader(new FileReader("payroll_data.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] row = line.split("\t");
                if (row.length == 6) {
                    boolean isAdmin = role.equals("admin");
                    boolean isOwner = row[0].equals(employeeID);
                    if (isAdmin || isOwner) {
                        model.addRow(row);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void applyFilters() {
        if (!role.equals("admin")) return;

        String empIdFilter = filterIdField.getText().trim();
        String selectedPeriod = (String) periodComboBox.getSelectedItem();
        String selectedMonth = (String) monthComboBox.getSelectedItem();

        model.setRowCount(0);
        try (BufferedReader br = new BufferedReader(new FileReader("payroll_data.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] row = line.split("\t");
                if (row.length == 6) {
                    boolean matchesId = empIdFilter.isEmpty() || row[0].equals(empIdFilter);
                    boolean matchesPeriod = selectedPeriod.equals("All") || row[2].endsWith("-" + selectedPeriod);
                    boolean matchesMonth = selectedMonth.equals("All") || row[2].startsWith(selectedMonth);
                    if (matchesId && matchesPeriod && matchesMonth) {
                        model.addRow(row);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void calculateAndSavePayroll(String empId, String empName, String period, double hoursWorked, double ratePerHour) {
        double grossPay = hoursWorked * ratePerHour;
        double deductions = grossPay * 0.20;
        double netPay = grossPay - deductions;

        String rowData = String.format("%s\t%s\t%s\t%.2f\t%.2f\t%.2f", empId, empName, period, grossPay, deductions, netPay);

        try (BufferedWriter writer = new BufferedWriter(new FileWriter("payroll_data.txt", true))) {
            writer.write(rowData);
            writer.newLine();
            JOptionPane.showMessageDialog(this, "Payroll calculated and saved!");
            loadPayrollData();
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error saving payroll.");
        }
    }

    private double calculateHoursFromLog(String empId, String period, int selectedMonthIndex) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader("attendance_log.txt"));
        String line;
        double totalHours = 0.0;

        while ((line = br.readLine()) != null) {
            String[] parts = line.split("\t");
            if (parts.length != 6) continue;
            if (!parts[0].trim().equals(empId)) continue;

            String date = parts[3].trim();
            String timeIn = parts[4].trim();
            String timeOut = parts[5].trim();

            if (!isWithinPeriod(date, period, selectedMonthIndex)) continue;

            try {
                long inMillis = parseTime(date + " " + timeIn);
                long outMillis = parseTime(date + " " + timeOut);
                double hours = (outMillis - inMillis) / (1000.0 * 60 * 60);
                if (hours > 0 && hours <= 24) {
                    totalHours += hours;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        br.close();
        return totalHours;
    }

    private boolean isWithinPeriod(String dateStr, String period, int selectedMonthIndex) {
        try {
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("MM/dd/yyyy");
            java.util.Date date = sdf.parse(dateStr);
            java.util.Calendar cal = java.util.Calendar.getInstance();
            cal.setTime(date);

            int month = cal.get(java.util.Calendar.MONTH); // 0-based
            int day = cal.get(java.util.Calendar.DAY_OF_MONTH);

            if (month != selectedMonthIndex) return false;

            if (period.equals("15")) {
                return day >= 1 && day <= 15;
            } else if (period.equals("30")) {
                return day >= 16 && day <= 31;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    private long parseTime(String dateTimeStr) throws Exception {
        java.text.SimpleDateFormat format = new java.text.SimpleDateFormat("MM/dd/yyyy HH:mm");
        java.util.Date date = format.parse(dateTimeStr);
        return date.getTime();
    }

    private String getEmployeeFullName(String empId) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader("attendance_log.txt"));
        String line;
        while ((line = br.readLine()) != null) {
            String[] parts = line.split("\t");
            if (parts.length >= 3 && parts[0].trim().equals(empId)) {
                String lastName = parts[1].trim();
                String firstName = parts[2].trim();
                br.close();
                return firstName + " " + lastName;
            }
        }
        br.close();
        return "";
    }

    private double getHourlyRate(String empId) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader("hourly_rates.txt"));
        String line;
        while ((line = br.readLine()) != null) {
            String[] parts = line.split("\t");
            if (parts.length >= 3 && parts[0].trim().equals(empId)) {
                try {
                    return Double.parseDouble(parts[2].trim());
                } catch (NumberFormatException e) {
                    return 0.0;
                }
            }
        }
        br.close();
        return 0.0;
    }
}
