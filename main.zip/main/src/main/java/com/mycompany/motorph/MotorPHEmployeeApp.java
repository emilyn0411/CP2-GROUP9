
package com.mycompany.motorph;

public class MotorPHEmployeeApp {
    public static void main(String[] args) {
        // Start your app here, for example:
        LoginScreen.main(args);
    }
}